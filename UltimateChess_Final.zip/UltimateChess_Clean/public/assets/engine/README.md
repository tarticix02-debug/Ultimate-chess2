Stockfish motor dosyaları bu klasöre eklenmelidir: stockfish.js ve stockfish.wasm.
