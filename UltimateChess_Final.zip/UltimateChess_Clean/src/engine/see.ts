import { Chess, type Square, type PieceSymbol, type Color } from 'chess.js';
const PIECE_VALUE: Record<PieceSymbol, number> = { p:100,n:320,b:330,r:500,q:900,k:20000 };
function attackers(fen:string,target:Square,color:Color){ try { const parts=fen.split(' '); parts[1]=color; parts[3]='-'; const c=new Chess(parts.join(' ')); return c.moves({verbose:true}).filter(m=>m.to===target).map(m=>PIECE_VALUE[m.piece as PieceSymbol]); } catch { return []; } }
export function staticExchangeEval(fen:string,target:Square):number { const c=new Chess(fen); const victim=c.get(target); if(!victim) return 0; const enemy:Color=victim.color==='w'?'b':'w'; const a=attackers(fen,target,enemy).sort((x,y)=>x-y); if(!a.length) return 0; return PIECE_VALUE[victim.type]-a[0]; }
