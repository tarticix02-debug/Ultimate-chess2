export type MoveClass='brilliant'|'best'|'great'|'excellent'|'good'|'inaccuracy'|'mistake'|'blunder'|'miss'|'book';
export interface EngineSample{cpWhite:number|null;mateWhite:number|null;}
export function toWhitePerspective(side:'w'|'b',cp:number|null,mate:number|null):EngineSample{return mate!==null?{cpWhite:null,mateWhite:side==='w'?mate:-mate}:{cpWhite:side==='w'?(cp??0):-(cp??0),mateWhite:null};}
const clamp=(v:number,min:number,max:number)=>Math.max(min,Math.min(max,v));
export function winPercentWhite(s:EngineSample){if(s.mateWhite!==null)return s.mateWhite>0?100:0;const cp=clamp(s.cpWhite??0,-1000,1000);return clamp(50+50*(2/(1+Math.exp(-0.00368208*cp))-1),0,100);}
export function accuracyFromLoss(loss:number){return clamp(103.1668*Math.exp(-0.04354*loss)-3.1669,0,100);}
export function classifyMove(p:{winPercentLoss:number;playedIsTopEngineMove:boolean;topMoveCriticalityGap:number;isBookMove:boolean}):MoveClass{if(p.isBookMove)return'book';if(p.playedIsTopEngineMove)return p.topMoveCriticalityGap>=8?'great':'best';if(p.winPercentLoss<2)return'excellent';if(p.winPercentLoss<5)return'good';if(p.winPercentLoss<10)return'inaccuracy';if(p.winPercentLoss<20)return'mistake';return'blunder';}
export interface BrilliantCheckParams{legalMoveCountBefore:number;moverWinPercentBefore:number;moverWinPercentAfter:number;winPercentLoss:number;fenAfter:string;destSquare:string;}
export function isBrilliantMove(p:BrilliantCheckParams,seeFn:(fen:string,square:string)=>number){return p.winPercentLoss<2&&p.legalMoveCountBefore>1&&p.moverWinPercentBefore<97&&p.moverWinPercentAfter>=45&&seeFn(p.fenAfter,p.destSquare)>=150;}
const SYMBOLS:Record<MoveClass,string>={brilliant:'!!',great:'!',best:'★',excellent:'',good:'',inaccuracy:'?!',mistake:'?',blunder:'??',miss:'?!',book:''};
export function classificationSymbol(c:MoveClass){return SYMBOLS[c];}
