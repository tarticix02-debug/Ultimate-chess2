import { levelToOptions, type EngineOptions } from './levels';

export type EngineStatus = 'LOADING' | 'READY' | 'THINKING' | 'STOPPED' | 'ERROR';
export interface AnalysisLine { rank: number; moveUci: string; cp: number | null; mate: number | null; }
export interface AnalysisResult { requestId: string; bestMove: string | null; ponder: string | null; evaluationCp: number | null; mate: number | null; pv: string[]; depth: number; lines?: AnalysisLine[]; }

const ENGINE_URL = `${import.meta.env.BASE_URL}assets/engine/stockfish.js`;

export class StockfishEngine {
  private worker: Worker | null = null;
  private status: EngineStatus = 'LOADING';
  private listeners = new Set<(s: EngineStatus) => void>();
  private activeRequestId: string | null = null;
  private lastError: string | null = null;

  async init(timeoutMs = 8000): Promise<void> {
    if (this.worker) return;
    try { this.worker = new Worker(ENGINE_URL); }
    catch (e) { this.fail(`Motor worker'ı yüklenemedi: ${(e as Error).message}`); throw e; }
    this.worker.onerror = (e) => this.fail(`Motor çalışma hatası: ${e.message}`);
    await this.withTimeout(this.handshake(), timeoutMs, 'Motor başlatma zaman aşımı');
    this.setStatus('READY');
  }

  private handshake(): Promise<void> {
    return new Promise((resolve, reject) => {
      let uciOk = false;
      const handler = (e: MessageEvent) => {
        const line = String(e.data);
        if (line === 'uciok') { uciOk = true; this.send('isready'); }
        else if (line === 'readyok' && uciOk) { this.worker?.removeEventListener('message', handler); resolve(); }
      };
      this.worker!.addEventListener('message', handler);
      this.send('uci');
    });
  }

  private withTimeout<T>(p: Promise<T>, ms: number, msg: string): Promise<T> {
    return new Promise((resolve, reject) => {
      const t = setTimeout(() => { this.fail(msg); reject(new Error(msg)); }, ms);
      p.then(v => { clearTimeout(t); resolve(v); }, err => { clearTimeout(t); reject(err); });
    });
  }
  private send(cmd: string) { if (!this.worker) throw new Error('Motor henüz başlatılmadı'); this.worker.postMessage(cmd); }
  private setStatus(s: EngineStatus) { this.status = s; this.listeners.forEach(l => l(s)); }
  private fail(msg: string) { this.lastError = msg; this.setStatus('ERROR'); }
  getStatus() { return this.status; }
  getLastError() { return this.lastError; }
  onStatusChange(fn: (s: EngineStatus) => void) { this.listeners.add(fn); return () => this.listeners.delete(fn); }

  setLevel(level: number) {
    if (!this.worker || this.status === 'ERROR') return;
    const o: EngineOptions = levelToOptions(level);
    this.send(`setoption name UCI_LimitStrength value ${o.UCI_LimitStrength}`);
    if (o.UCI_Elo) this.send(`setoption name UCI_Elo value ${o.UCI_Elo}`);
    this.send(`setoption name Skill Level value ${o.SkillLevel}`);
    this.send(`setoption name Threads value ${o.Threads}`);
    this.send(`setoption name Hash value ${o.Hash}`);
    this.send(`setoption name MultiPV value ${o.MultiPV}`);
  }
  setMultiPV(n: number) { if (this.worker && this.status !== 'ERROR') this.send(`setoption name MultiPV value ${Math.max(1, Math.round(n))}`); }

  newGame(): Promise<void> {
    if (!this.worker || this.status === 'ERROR') return Promise.reject(new Error('Motor hazır değil'));
    this.stop(); this.send('ucinewgame');
    return new Promise(resolve => {
      const handler = (e: MessageEvent) => { if (String(e.data) === 'readyok') { this.worker?.removeEventListener('message', handler); resolve(); } };
      this.worker!.addEventListener('message', handler); this.send('isready');
    });
  }
  stop() { if (this.status === 'THINKING' && this.worker) this.send('stop'); this.activeRequestId = null; }

  analyze(fen: string, opts: { movetimeMs?: number; depth?: number }, requestId: string): Promise<AnalysisResult> {
    if (!this.worker || (this.status !== 'READY' && this.status !== 'STOPPED')) return Promise.reject(new Error(`Motor hazır değil (durum: ${this.status})`));
    this.stop(); this.activeRequestId = requestId; this.setStatus('THINKING'); this.send(`position fen ${fen}`);
    const info: Partial<AnalysisResult> = { pv: [] };
    const pvLines = new Map<number, AnalysisLine>();
    return new Promise((resolve, reject) => {
      const handler = (e: MessageEvent) => {
        const line = String(e.data);
        if (line.startsWith('info')) {
          const d = /depth (\d+)/.exec(line), mpv = /multipv (\d+)/.exec(line), cp = /score cp (-?\d+)/.exec(line), mate = /score mate (-?\d+)/.exec(line), pv = / pv (.+)$/.exec(line);
          if (d) info.depth = Number(d[1]);
          if (pv) {
            const rank = mpv ? Number(mpv[1]) : 1;
            const moveUci = pv[1].trim().split(/\s+/)[0];
            pvLines.set(rank, { rank, moveUci, cp: cp ? Number(cp[1]) : null, mate: mate ? Number(mate[1]) : null });
            if (rank === 1) { info.evaluationCp = cp ? Number(cp[1]) : null; info.mate = mate ? Number(mate[1]) : null; info.pv = pv[1].trim().split(/\s+/); }
          }
        } else if (line.startsWith('bestmove')) {
          this.worker?.removeEventListener('message', handler);
          if (this.activeRequestId !== requestId) { reject(new Error('STALE_RESPONSE')); return; }
          this.setStatus('STOPPED');
          const parts = line.trim().split(/\s+/);
          resolve({ requestId, bestMove: parts[1] && parts[1] !== '(none)' ? parts[1] : null, ponder: parts[2] === 'ponder' ? parts[3] ?? null : null, evaluationCp: info.evaluationCp ?? null, mate: info.mate ?? null, pv: info.pv ?? [], depth: info.depth ?? 0, lines: [...pvLines.values()].sort((a,b) => a.rank-b.rank) });
        }
      };
      this.worker!.addEventListener('message', handler);
      this.send(opts.depth ? `go depth ${opts.depth}` : `go movetime ${opts.movetimeMs ?? 1000}`);
    });
  }
  analyzeMultiPV(fen: string, opts: { depth?: number; movetimeMs?: number }, requestId: string) { return this.analyze(fen, opts, requestId); }
  destroy() { this.stop(); this.worker?.terminate(); this.worker = null; this.listeners.clear(); this.setStatus('LOADING'); }
}
