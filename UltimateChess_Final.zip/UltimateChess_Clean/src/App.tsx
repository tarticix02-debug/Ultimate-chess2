import { BrowserRouter, Routes, Route } from 'react-router-dom';  
import { useEffect } from 'react';  
import { useTheme } from './hooks/useTheme';  
import { BottomNav } from './components/nav/BottomNav';  
import { HomeScreen } from './screens/HomeScreen';  
import { PlayScreen } from './screens/PlayScreen';  
import { VariantsScreen } from './screens/VariantsScreen';  
import { StatsScreen } from './screens/StatsScreen';  
import { GameReviewScreen } from './screens/GameReviewScreen';  
import { PuzzleScreen } from './screens/PuzzleScreen';
import { OpeningsScreen } from './screens/OpeningsScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { SettingsScreen } from './screens/SettingsScreen';  
import './styles/tokens.css';  
import './styles/global.css';  
  
export function App() {  
  const { settings } = useTheme();  
  
  if (!settings) {  
    return <div className="app-boot-loading"><div className="spinner" /></div>;  
  }  
  
  return (  
    <BrowserRouter>  
      <div className="app-shell">  
        <main className="app-shell__content">  
          <Routes>  
            <Route path="/" element={<HomeScreen />} />  
            <Route path="/play" element={<PlayScreen />} />  
            <Route path="/play/variant/:variantId" element={<PlayScreen />} />  
            <Route path="/variants" element={<VariantsScreen />} />  
            <Route path="/stats" element={<StatsScreen />} />  
            <Route path="/review/:gameId" element={<GameReviewScreen />} />  
            <Route path="/puzzle" element={<PuzzleScreen />} />  
            <Route path="/openings" element={<OpeningsScreen />} />  
            <Route path="/profile" element={<ProfileScreen />} />  
            <Route path="/settings" element={<SettingsScreen />} />  
          </Routes>  
        </main>  
        <BottomNav />  
      </div>  
    </BrowserRouter>  
  );  
}
