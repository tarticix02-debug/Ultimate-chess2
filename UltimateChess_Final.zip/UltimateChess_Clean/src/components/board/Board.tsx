import { useMemo, useState } from 'react';
import type { Square } from 'chess.js';
import { PieceIcon } from './PieceIcon';
import { PromotionPicker } from './PromotionPicker';
import { useGameStore } from '../../state/gameStore';
import { useTheme } from '../../hooks/useTheme';

const FILES = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];

export function Board() {
const { game, lastMove, checkSquare, legalMovesForSquare, playMove, visibilityMask, orientation } = useGameStore();
const { settings } = useTheme();
const [selected, setSelected] = useState<Square | null>(null);
const [pendingPromotion, setPendingPromotion] = useState<{ from: Square; to: Square } | null>(null);

const board = useMemo(() => game.board(), [game]);
const movesFromSelected = selected ? legalMovesForSquare(selected) : [];
const targets = useMemo(() => Array.from(new Set(movesFromSelected.map((m) => m.to))), [movesFromSelected]);

const ranks = orientation === 'w' ? [8, 7, 6, 5, 4, 3, 2, 1] : [1, 2, 3, 4, 5, 6, 7, 8];
const files = orientation === 'w' ? FILES : [...FILES].reverse();

function onSquareClick(square: Square) {
if (pendingPromotion) return;
if (selected && targets.includes(square)) {
const isPromotion = movesFromSelected.some((m) => m.to === square && m.promotion);
if (isPromotion) {
if (settings?.autoPromoteToQueen) {
playMove(selected, square, 'q');
setSelected(null);
} else {
setPendingPromotion({ from: selected, to: square });
}
} else {
playMove(selected, square);
setSelected(null);
}
return;
}
const piece = game.raw.get(square);
if (piece) setSelected(square);
else setSelected(null);
}

function resolvePromotion(piece: 'q' | 'r' | 'b' | 'n') {
if (!pendingPromotion) return;
playMove(pendingPromotion.from, pendingPromotion.to, piece);
setPendingPromotion(null);
setSelected(null);
}

return (
<div className="board-wrapper">
<div className="board-grid" role="grid" aria-label="Satranç tahtası">
{ranks.map((rank) =>
files.map((file) => {
const square = `${file}${rank}` as Square;
const rowIdx = 8 - rank;
const colIdx = FILES.indexOf(file);
const cell = board[rowIdx][colIdx];
const isDark = (rowIdx + colIdx) % 2 === 1;
const isSelected = selected === square;
const isTarget = settings?.legalMoveHighlights !== false && targets.includes(square);
const isLastMove = settings?.showLastMoveHighlight !== false && lastMove && (lastMove.from === square || lastMove.to === square);
const isCheck = checkSquare === square;
const visible = visibilityMask ? visibilityMask[rowIdx][colIdx] : true;

return (  
          <button  
            key={square}  
            className={['square', isDark ? 'square--dark' : 'square--light', isSelected && 'square--selected', isTarget && 'square--target', isLastMove && 'square--last-move', isCheck && 'square--check'].filter(Boolean).join(' ')}  
            onClick={() => onSquareClick(square)}  
            aria-label={`${square}${cell && visible ? ' - ' + cell.type : ''}`}  
          >  
            {cell && visible && <PieceIcon type={cell.type} color={cell.color} />}  
            {isTarget && !cell && <span className="square__dot" />}  
          </button>  
        );  
      })  
    )}  
  </div>  
  {pendingPromotion && (  
    <PromotionPicker  
      color={orientation}  
      onSelect={resolvePromotion}  
      onCancel={() => { setPendingPromotion(null); setSelected(null); }}  
    />  
  )}  
</div>

);
}
