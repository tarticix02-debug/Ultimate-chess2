import type { ReactNode } from 'react';  
  
interface CardProps {  
  children: ReactNode;  
  onClick?: () => void;  
  disabled?: boolean;  
  className?: string;  
  ariaLabel?: string;  
}  
  
export function Card({ children, onClick, disabled, className = '', ariaLabel }: CardProps) {  
  const Tag = onClick ? 'button' : 'div';  
  return (  
    <Tag  
      className={`card ${onClick ? 'card--interactive' : ''} ${disabled ? 'card--disabled' : ''} ${className}`}  
      onClick={disabled ? undefined : onClick}  
      aria-label={ariaLabel}  
      aria-disabled={disabled}  
    >  
      {children}  
    </Tag>  
  );  
}
