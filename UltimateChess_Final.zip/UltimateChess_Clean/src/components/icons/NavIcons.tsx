const common={width:22,height:22,viewBox:'0 0 24 24',fill:'none',stroke:'currentColor',strokeWidth:1.8,strokeLinecap:'round' as const,strokeLinejoin:'round' as const};
export const HomeIcon=()=> <svg {...common}><path d="M4 11l8-7 8 7v9a1 1 0 01-1 1h-4v-6H9v6H5a1 1 0 01-1-1z"/></svg>;
export const PlayIcon=()=> <svg {...common}><circle cx="12" cy="12" r="9"/><path d="M10 8l6 4-6 4z"/></svg>;
export const GridIcon=()=> <svg {...common}><rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/></svg>;
export const ChartIcon=()=> <svg {...common}><path d="M5 19V9M12 19V5M19 19v-7"/></svg>;
export const GearIcon=()=> <svg {...common}><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 00-.2-1.6l2-1.4-2-3.4-2.3.8a7 7 0 00-2.7-1.6L13.4 2h-2.8l-.4 2.8a7 7 0 00-2.7 1.6l-2.3-.8-2 3.4 2 1.4A7 7 0 005 12c0 .5.1 1.1.2 1.6l-2 1.4 2 3.4 2.3-.8a7 7 0 002.7 1.6l.4 2.8h2.8l.4-2.8a7 7 0 002.7-1.6l2.3.8 2-3.4-2-1.4c.1-.5.2-1.1.2-1.6z"/></svg>;
