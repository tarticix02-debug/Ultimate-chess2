import { NavLink } from 'react-router-dom';  
import { HomeIcon, PlayIcon, GridIcon, ChartIcon, GearIcon } from '../icons/NavIcons';  
  
const ITEMS = [  
  { to: '/', label: 'Ana Sayfa', Icon: HomeIcon, end: true },  
  { to: '/play', label: 'Oyna', Icon: PlayIcon, end: false },  
  { to: '/variants', label: 'Varyantlar', Icon: GridIcon, end: false },  
  { to: '/stats', label: 'İstatistik', Icon: ChartIcon, end: false },  
  { to: '/settings', label: 'Ayarlar', Icon: GearIcon, end: false },  
];  
  
export function BottomNav() {  
  return (  
    <nav className="bottom-nav" role="navigation" aria-label="Ana gezinme">  
      {ITEMS.map(({ to, label, Icon, end }) => (  
        <NavLink  
          key={to}  
          to={to}  
          end={end}  
          className={({ isActive }) => `bottom-nav__item ${isActive ? 'bottom-nav__item--active' : ''}`}  
        >  
          <Icon />  
          <span>{label}</span>  
        </NavLink>  
      ))}  
    </nav>  
  );  
}
