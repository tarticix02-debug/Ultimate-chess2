import type { ChessGame } from '../../chess/ChessGame';
import type { VariantRuntimeState } from '../types';
import { StockfishEngine } from '../../engine/StockfishEngine';

/**

Standart Stockfish, varyant kurallarını (donma, görünmezlik, jackpot vb.) BİLMEZ.

Bu adapter, motor önerisini alır ama uygulamadan önce varyantın onBeforeMove

kısıtlamalarına göre FİLTRELER. Motor önerisi yasaksa alternatif legal hamle seçilir.

Bu, "Stockfish özel modu anlıyor" yanılsaması yaratmadan güvenli bir yaklaşımdır.
*/
export class VariantAIAdapter {
constructor(private engine: StockfishEngine) {}


async pickMove(game: ChessGame, variantState: VariantRuntimeState, guard: (from: string, to: string) => boolean): Promise<{ from: string; to: string; promotion?: string } | null> {
const legal = game.legalMoves();
const allowed = legal.filter((m) => guard(m.from, m.to));
if (!allowed.length) return null;

try {  
  const result = await this.engine.analyze(game.fen(), { movetimeMs: 800 }, `variant-${Date.now()}`);  
  if (result.bestMove) {  
    const from = result.bestMove.slice(0, 2);  
    const to = result.bestMove.slice(2, 4);  
    if (guard(from, to)) return { from, to, promotion: result.bestMove.slice(4) || undefined };  
  }  
} catch {  
  // motor önerisi alınamazsa aşağıdaki fallback'e düş  
}  
// motor önerisi varyant kuralına uymuyorsa ya da motor hata verdiyse:  
// izinli hamleler arasından materyal değerine göre basit greedy seçim (gerçek ama sınırlı bir AI, sahte rastgelelik değil)  
const scored = allowed.map((m) => ({ m, score: captureValue(m) }));  
scored.sort((a, b) => b.score - a.score);  
const pick = scored[0].m;  
return { from: pick.from, to: pick.to, promotion: pick.promotion };

}
}

function captureValue(m: { captured?: string }): number {
const values: Record<string, number> = { p: 1, n: 3, b: 3, r: 5, q: 9 };
return m.captured ? values[m.captured] ?? 0 : 0;
}
