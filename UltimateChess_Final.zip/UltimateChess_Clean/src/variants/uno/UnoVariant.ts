import type { VariantRule, VariantEvent, VariantActionResult, VariantRuntimeState } from '../types';
import type { ChessGame } from '../../chess/ChessGame';
import { buildStandardDeck, shuffle, canPlay, type UnoCard, type UnoColor } from './unoDeck';
import { uid } from '../../utils/id';

interface UnoCustomData {
  deck: UnoCard[];
  discard: UnoCard[];
  hands: { w: UnoCard[]; b: UnoCard[] };
  topColor: UnoColor;
  topValue: UnoCard['value'];
  hasPlayedCardThisTurn: { w: boolean; b: boolean };
  pendingSkip: { drawCount: number } | null;
  bonusMoveFor: 'w' | 'b' | null;
}

const event = (type: string, description: string, payload: Record<string, unknown> = {}): VariantEvent => ({ id: uid(), type, description, payload, appliedAt: Date.now() });
const label = (c: 'w' | 'b') => c === 'w' ? 'Beyaz' : 'Siyah';
function reshuffle(data: UnoCustomData) {
  if (data.discard.length <= 1) return;
  const top = data.discard[data.discard.length - 1];
  data.deck.push(...shuffle(data.discard.slice(0, -1)));
  data.discard = [top];
}
function draw(data: UnoCustomData, color: 'w' | 'b') {
  if (!data.deck.length) reshuffle(data);
  const card = data.deck.shift();
  if (card) data.hands[color].push(card);
}

export const UnoVariant: VariantRule = {
  id: 'uno',
  name: 'UNO Chess',
  description: 'Gerçek 108 kartlık UNO destesi kullanılır. Hamleden önce eşleşen kart oynayarak özel etkiler uygulanabilir.',
  status: 'implemented',
  initialize: (): VariantRuntimeState => {
    const deck = shuffle(buildStandardDeck());
    const first = deck.shift()!;
    return {
      variantId: 'uno', moveCounter: 0,
      customData: { deck, discard: [first], hands: { w: deck.splice(0, 7), b: deck.splice(0, 7) }, topColor: first.color, topValue: first.value, hasPlayedCardThisTurn: { w: false, b: false }, pendingSkip: null, bonusMoveFor: null },
      activeEvents: [], log: [],
    };
  },
  applyCustomAction: (state, game, action, actingColor): VariantActionResult => {
    const data = state.customData as UnoCustomData;
    if (data.hasPlayedCardThisTurn[actingColor]) return { success: false, reason: 'Bu turda zaten bir kart oynadınız.', events: [] };
    if (action.type === 'DRAW_CARD') { draw(data, actingColor); data.hasPlayedCardThisTurn[actingColor] = true; return { success: true, events: [event('UNO_DRAW', `${label(actingColor)} bir kart çekti.`)] }; }
    if (action.type !== 'PLAY_CARD') return { success: false, reason: 'Bilinmeyen UNO eylemi.', events: [] };
    const cardId = action.payload?.cardId as string | undefined;
    const hand = data.hands[actingColor];
    const index = hand.findIndex(c => c.id === cardId);
    if (index < 0) return { success: false, reason: 'Bu kart elinizde yok.', events: [] };
    const card = hand[index];
    const chosenColor = (action.payload?.chosenColor as UnoColor | undefined) ?? 'red';
    if (!canPlay(card, data.topColor, data.topValue)) return { success: false, reason: 'Bu kart mevcut renk veya değerle eşleşmiyor.', events: [] };
    hand.splice(index, 1); data.discard.push(card); data.topValue = card.value; data.topColor = card.color === 'wild' ? chosenColor : card.color; data.hasPlayedCardThisTurn[actingColor] = true;
    const opponent: 'w' | 'b' = actingColor === 'w' ? 'b' : 'w';
    const events = [event('UNO_PLAY', `${label(actingColor)} bir UNO kartı oynadı.`, { card })];
    if (card.value === 'skip' || card.value === 'reverse') data.pendingSkip = { drawCount: 0 };
    if (card.value === 'draw2') data.pendingSkip = { drawCount: 2 };
    if (card.value === 'wild4') data.pendingSkip = { drawCount: 4 };
    if (data.pendingSkip) events.push(event('UNO_EFFECT', `${label(opponent)} sırasını kaybedecek.`, { drawCount: data.pendingSkip.drawCount }));
    if (!hand.length) data.bonusMoveFor = actingColor;
    return { success: true, events };
  },
  onBeforeMove: (state) => ({ allowed: !(state.customData as UnoCustomData).pendingSkip }),
  onAfterMove: (state, game) => {
    const data = state.customData as UnoCustomData;
    const mover: 'w' | 'b' = game.raw.turn() === 'w' ? 'b' : 'w';
    const events: VariantEvent[] = [];
    if (data.pendingSkip) {
      const opponent: 'w' | 'b' = mover === 'w' ? 'b' : 'w';
      for (let i = 0; i < data.pendingSkip.drawCount; i++) draw(data, opponent);
      game.forceActiveColor(mover); data.hasPlayedCardThisTurn[mover] = false;
      events.push(event('UNO_TURN_SKIPPED', `${label(opponent)} sırası atlandı.`)); data.pendingSkip = null;
    } else if (data.bonusMoveFor === mover) {
      game.forceActiveColor(mover); data.hasPlayedCardThisTurn[mover] = false; events.push(event('UNO_BONUS_MOVE', `${label(mover)} ekstra hamle kazandı.`)); data.bonusMoveFor = null;
    } else {
      data.hasPlayedCardThisTurn[game.raw.turn()] = false;
    }
    state.moveCounter++; state.activeEvents = events; state.log.push(...events); return events;
  },
  decideAIPreMoveAction: (state, _game, aiColor) => {
    const data = state.customData as UnoCustomData;
    const hand = data.hands[aiColor];
    const card = hand.find(c => canPlay(c, data.topColor, data.topValue));
    return card ? { type: 'PLAY_CARD', payload: { cardId: card.id, chosenColor: 'red' } } : { type: 'DRAW_CARD', payload: {} };
  },
};
