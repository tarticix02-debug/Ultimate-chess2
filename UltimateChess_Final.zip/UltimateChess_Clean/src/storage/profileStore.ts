import { dbGetAll, dbPut } from './db';  
  
export interface UserProfile {  
  id: string;  
  username: string;  
  avatarInitial: string;  
  rating: number;  
  puzzleRating: number; // Puzzle sistemi kurulana kadar kullanılmaz, dashboard'da gösterilmez.  
  createdAt: number;  
}  
  
const PROFILE_ID = 'local-user';  
  
/**  
 * NOT: Şu an tek yerel profil desteklenir (backend/auth yok).  
 * 1200 başlangıç Elo'su, chess.com/lichess benzeri standart bir varsayımdır;  
 * "hesaplanmış veri" olarak sunulmaz, açıkça bir varsayılan değerdir.  
 */  
const DEFAULT_PROFILE: UserProfile = {  
  id: PROFILE_ID,  
  username: 'Oyuncu',  
  avatarInitial: 'O',  
  rating: 1200,  
  puzzleRating: 1200,  
  createdAt: Date.now(),  
};  
  
export async function getProfile(): Promise<UserProfile> {  
  const all = await dbGetAll<UserProfile>('profile');  
  const existing = all.find((p) => p.id === PROFILE_ID);  
  if (existing) return existing;  
  await dbPut('profile', DEFAULT_PROFILE);  
  return DEFAULT_PROFILE;  
}  
  
export async function updateProfile(patch: Partial<UserProfile>): Promise<UserProfile> {  
  const current = await getProfile();  
  const updated: UserProfile = { ...current, ...patch, id: PROFILE_ID };  
  await dbPut('profile', updated);  
  return updated;  
}
