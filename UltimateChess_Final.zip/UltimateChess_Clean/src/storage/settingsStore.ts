import { dbGetAll, dbPut } from './db';

export interface AppSettings {
id: string;
theme: 'dark' | 'light' | 'system';
accentColor: string;
soundEnabled: boolean;
hapticEnabled: boolean;
language: 'tr' | 'en';
legalMoveHighlights: boolean;
showLastMoveHighlight: boolean;
autoPromoteToQueen: boolean;
puzzleGenProcessedGameIds: string[];
}

const SETTINGS_ID = 'app-settings';
const DEFAULT_SETTINGS: AppSettings = {
id: SETTINGS_ID, theme: 'dark', accentColor: '#4f8cff',
soundEnabled: true, hapticEnabled: true, language: 'tr',
legalMoveHighlights: true, showLastMoveHighlight: true, autoPromoteToQueen: false,
puzzleGenProcessedGameIds: [],
};

export async function getSettings(): Promise<AppSettings> {
const all = await dbGetAll<AppSettings>('settings');
const existing = all.find((s) => s.id === SETTINGS_ID);
if (existing) return { ...DEFAULT_SETTINGS, ...existing }; // eski kayıtlarda eksik yeni alanları tamamlar
await dbPut('settings', DEFAULT_SETTINGS);
return DEFAULT_SETTINGS;
}

export async function updateSettings(patch: Partial<AppSettings>): Promise<AppSettings> {
const current = await getSettings();
const updated = { ...current, ...patch, id: SETTINGS_ID };
await dbPut('settings', updated);
return updated;
}
