import { Chess } from 'chess.js';

export interface ReplayStep {
ply: number;
side: 'w' | 'b';
moveSan: string;
moveUci: string;
fenBefore: string;
}

/** PGN'i chess.js ile gerçekten oynatarak her hamleden önceki FEN'i üretir. */
export function buildReplay(pgn: string): ReplayStep[] {
const parsed = new Chess();
parsed.loadPgn(pgn);
const history = parsed.history({ verbose: true });

const replay = new Chess();
const steps: ReplayStep[] = [];
history.forEach((mv, idx) => {
const fenBefore = replay.fen();
const side = replay.turn();
replay.move({ from: mv.from, to: mv.to, promotion: mv.promotion });
steps.push({
ply: idx,
side,
moveSan: mv.san,
moveUci: `${mv.from}${mv.to}${mv.promotion ?? ''}`,
fenBefore,
});
});
return steps;
}

export function finalFen(pgn: string): string {
const c = new Chess();
c.loadPgn(pgn);
return c.fen();
}
