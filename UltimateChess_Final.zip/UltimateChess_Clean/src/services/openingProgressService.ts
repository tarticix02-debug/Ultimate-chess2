import { dbGetAll, dbPut } from '../storage/db';  
import type { OpeningLine } from '../openings/types';  
  
export interface OpeningProgressRecord {  
  id: string;  
  lineName: string;  
  eco: string;  
  timesTrained: number;  
  timesMistakeFree: number;  
  totalMistakes: number;  
  lastTrainedAt: number;  
  mistakePlies: Record<number, number>;  
}  
  
export function lineId(line: OpeningLine): string {  
  return `${line.eco}__${line.name}`.replace(/\s+/g, '_');  
}  
  
export async function getProgressForLine(line: OpeningLine): Promise<OpeningProgressRecord> {  
  const all = await dbGetAll<OpeningProgressRecord>('openingProgress');  
  const id = lineId(line);  
  return all.find((r) => r.id === id) ?? {  
    id, lineName: line.name, eco: line.eco,  
    timesTrained: 0, timesMistakeFree: 0, totalMistakes: 0, lastTrainedAt: 0, mistakePlies: {},  
  };  
}  
  
export async function getAllProgress(): Promise<OpeningProgressRecord[]> {  
  return dbGetAll<OpeningProgressRecord>('openingProgress');  
}  
  
export async function recordTrainingSession(line: OpeningLine, mistakePlies: number[]): Promise<OpeningProgressRecord> {  
  const current = await getProgressForLine(line);  
  const updated: OpeningProgressRecord = {  
    ...current,  
    timesTrained: current.timesTrained + 1,  
    timesMistakeFree: mistakePlies.length === 0 ? current.timesMistakeFree + 1 : current.timesMistakeFree,  
    totalMistakes: current.totalMistakes + mistakePlies.length,  
    lastTrainedAt: Date.now(),  
    mistakePlies: { ...current.mistakePlies },  
  };  
  for (const ply of mistakePlies) updated.mistakePlies[ply] = (updated.mistakePlies[ply] ?? 0) + 1;  
  await dbPut('openingProgress', updated);  
  return updated;  
}  
  
/** Basit spaced-repetition ağırlığı: çok hata yapılan / hiç çalışılmamış / uzun süredir çalışılmamış satırlar önceliklidir. */  
export function priorityScore(record: OpeningProgressRecord): number {  
  const hoursSince = record.lastTrainedAt === 0 ? 1000 : Math.min(500, (Date.now() - record.lastTrainedAt) / (1000 * 60 * 60));  
  const mistakeWeight = record.totalMistakes * 50;  
  const neverTrainedBonus = record.timesTrained === 0 ? 300 : 0;  
  return hoursSince + mistakeWeight + neverTrainedBonus;  
}  
  
export function pickNextLine(lines: OpeningLine[], progress: OpeningProgressRecord[]): OpeningLine {  
  const progressMap = new Map(progress.map((p) => [p.id, p]));  
  const scored = lines.map((line) => {  
    const id = lineId(line);  
    const rec = progressMap.get(id) ?? {  
      id, lineName: line.name, eco: line.eco,  
      timesTrained: 0, timesMistakeFree: 0, totalMistakes: 0, lastTrainedAt: 0, mistakePlies: {},  
    };  
    return { line, score: priorityScore(rec) };  
  });  
  scored.sort((a, b) => b.score - a.score);  
  const top = scored.slice(0, Math.min(5, scored.length));  
  return top[Math.floor(Math.random() * top.length)].line;  
}
