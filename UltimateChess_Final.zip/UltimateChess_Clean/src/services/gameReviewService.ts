import { StockfishEngine } from '../engine/StockfishEngine';
import { buildReplay, finalFen } from '../chess/replay';
import { toWhitePerspective, winPercentWhite, accuracyFromLoss, classifyMove, type MoveClass } from '../engine/evaluation';
import { identifyOpening } from './openingService';
import { uid } from '../utils/id';

export interface MoveReview {
ply: number;
side: 'w' | 'b';
san: string;
fenBefore: string;
fenAfter: string;
playedUci: string;
bestUci: string | null;
evalBeforeWhiteCp: number | null;
evalAfterWhiteCp: number | null;
evalAfterMate: number | null;
winPercentLoss: number;
accuracy: number;
classification: MoveClass;
isBookMove: boolean;
}

export interface GameReviewResult {
moves: MoveReview[];
evalHistoryWhiteCp: (number | null)[]; // N+1 nokta (başlangıç dahil)
whiteAccuracy: number;
blackAccuracy: number;
openingName: string | null;
openingEco: string | null;
}

export interface ReviewOptions {
depth?: number;
onProgress?: (done: number, total: number) => void;
signal?: { cancelled: boolean };
}

interface PositionSample {
cpWhite: number | null;
mateWhite: number | null;
bestUci: string | null;
secondCpWhite: number | null;
secondMateWhite: number | null;
}

export async function analyzeGame(pgn: string, options: ReviewOptions = {}): Promise<GameReviewResult> {
const depth = options.depth ?? 14;
const steps = buildReplay(pgn);
const fens = [...steps.map((s) => s.fenBefore), finalFen(pgn)];

// Canlı oyundan TAMAMEN bağımsız, ayrı bir motor instance'ı.
const engine = new StockfishEngine();
await engine.init();
engine.setMultiPV(2);
engine.setLevel(20); // Analiz her zaman tam güçle yapılır, seviye sınırlaması yoktur.

const samples: PositionSample[] = [];

try {
for (let i = 0; i < fens.length; i++) {
if (options.signal?.cancelled) throw new Error('CANCELLED');

const sideToMove = fens[i].split(' ')[1] as 'w' | 'b';  
  const result = await engine.analyzeMultiPV(fens[i], { depth }, `review-${i}-${uid()}`);  
  const top = result.lines?.[0];  
  const second = result.lines?.[1];  

  const whiteTop = toWhitePerspective(sideToMove, top?.cp ?? result.evaluationCp, top?.mate ?? result.mate);  
  const whiteSecond = second ? toWhitePerspective(sideToMove, second.cp, second.mate) : { cpWhite: null, mateWhite: null };  

  samples.push({  
    cpWhite: whiteTop.cpWhite,  
    mateWhite: whiteTop.mateWhite,  
    bestUci: top?.moveUci ?? result.bestMove,  
    secondCpWhite: whiteSecond.cpWhite,  
    secondMateWhite: whiteSecond.mateWhite,  
  });  

  options.onProgress?.(i + 1, fens.length);  
}

} finally {
engine.destroy(); // Worker kesinlikle temizlenir, memory leak bırakılmaz.
}

const moves: MoveReview[] = steps.map((step, i) => {
const before = samples[i];
const after = samples[i + 1];

const evalBeforeWhiteCp = before.mateWhite !== null ? mateToCp(before.mateWhite) : before.cpWhite;  
const evalAfterWhiteCp = after.mateWhite !== null ? mateToCp(after.mateWhite) : after.cpWhite;  

const winBefore = winPercentWhite({ cpWhite: before.cpWhite, mateWhite: before.mateWhite });  
const winAfter = winPercentWhite({ cpWhite: after.cpWhite, mateWhite: after.mateWhite });  

const loss = step.side === 'w' ? Math.max(0, winBefore - winAfter) : Math.max(0, winAfter - winBefore);  
const accuracy = accuracyFromLoss(loss);  

const bookInfo = identifyOpening(steps.slice(0, i + 1).map((s) => s.moveSan));  
const playedIsTop = before.bestUci === step.moveUci;  

let criticalityGap = 0;  
if (before.cpWhite !== null && before.secondCpWhite !== null) {  
  const topWin = winPercentWhite({ cpWhite: before.cpWhite, mateWhite: before.mateWhite });  
  const secondWin = winPercentWhite({ cpWhite: before.secondCpWhite, mateWhite: before.secondMateWhite });  
  criticalityGap = step.side === 'w' ? topWin - secondWin : secondWin - topWin;  
} else if (before.mateWhite !== null && before.secondCpWhite === null && before.secondMateWhite === null) {  
  criticalityGap = 100; // sadece mat veren tek hamle mevcut  
}  

const classification = classifyMove({  
  winPercentLoss: loss,  
  playedIsTopEngineMove: playedIsTop,  
  topMoveCriticalityGap: Math.max(0, criticalityGap),  
  isBookMove: bookInfo.matchedFullLine,  
});  

return {  
  ply: i, side: step.side, san: step.moveSan,  
  fenBefore: step.fenBefore, fenAfter: fens[i + 1],  
  playedUci: step.moveUci, bestUci: before.bestUci,  
  evalBeforeWhiteCp, evalAfterWhiteCp, evalAfterMate: after.mateWhite,  
  winPercentLoss: loss, accuracy, classification,  
  isBookMove: bookInfo.matchedFullLine,  
};

});

const avg = (arr: MoveReview[]) => (arr.length ? arr.reduce((s, m) => s + m.accuracy, 0) / arr.length : 0);
const opening = identifyOpening(steps.map((s) => s.moveSan));

return {
moves,
evalHistoryWhiteCp: samples.map((s) => (s.mateWhite !== null ? mateToCp(s.mateWhite) : s.cpWhite)),
whiteAccuracy: avg(moves.filter((m) => m.side === 'w')),
blackAccuracy: avg(moves.filter((m) => m.side === 'b')),
openingName: opening.name,
openingEco: opening.eco,
};
}

function mateToCp(mateWhite: number): number {
const magnitude = 10000 - Math.min(999, Math.abs(mateWhite)) * 10;
return mateWhite > 0 ? magnitude : -magnitude;
}
