import { QUEST_TEMPLATES } from '../quests/templates';
import { getAllDailySelections } from '../storage/dailyQuestSelectionStore';
import { getAllGames } from '../storage/gameHistoryStore';
import { dbGetAll } from '../storage/db';
import type { PuzzleAttemptRecord } from '../storage/puzzleAttemptTypes';
import type { OpeningSessionRecord } from '../storage/openingSessionStore';
import { dateKeyOf, dateFromKey, todayKey } from '../utils/date';
export interface DayCompletionRecord { dateKey:string; allCompleted:boolean; }
export function computeStreakFromRecords(records:DayCompletionRecord[],todayKeyStr:string){const map=new Map(records.map(r=>[r.dateKey,r.allCompleted]));let cursor=dateFromKey(todayKeyStr);if(map.has(todayKeyStr)&&map.get(todayKeyStr)===false)cursor.setDate(cursor.getDate()-1);let streak=0;while(true){const key=dateKeyOf(cursor.getTime());if(!map.has(key)||map.get(key)===false)break;streak++;cursor.setDate(cursor.getDate()-1);}return streak;}
export async function computeDailyQuestStreak(){const [selections,games,puzzles,openings]=await Promise.all([getAllDailySelections(),getAllGames(),dbGetAll<PuzzleAttemptRecord>('puzzleAttempts'),dbGetAll<OpeningSessionRecord>('openingSessions')]);const records=selections.map(sel=>{const key=sel.id;const ctx={gamesToday:games.filter(g=>dateKeyOf(g.date)===key),puzzleAttemptsToday:puzzles.filter(a=>dateKeyOf(a.date)===key),openingSessionsToday:openings.filter(s=>dateKeyOf(s.date)===key)};return {dateKey:key,allCompleted:sel.templateIds.every(id=>{const t=QUEST_TEMPLATES.find(x=>x.id===id);return !!t&&t.progress(ctx)>=t.target;})};});return computeStreakFromRecords(records,todayKey());}
