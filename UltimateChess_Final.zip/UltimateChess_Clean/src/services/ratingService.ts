/**  
 * Standart Elo formülü. Rating YALNIZCA klasik/bilgisayara karşı oyunlarda  
 * güncellenir. Varyant oyunları ayrı istatistik olarak sayılır (madde 22  
 * gereği "varyant performansı" ana rating'i etkilemez, bu bilinçli bir tercih).  
 */  
export function expectedScore(ratingA: number, ratingB: number): number {  
  return 1 / (1 + Math.pow(10, (ratingB - ratingA) / 400));  
}  
  
export function computeNewRating(  
  current: number,  
  opponent: number,  
  result: 'win' | 'loss' | 'draw',  
  kFactor = 32  
): number {  
  const score = result === 'win' ? 1 : result === 'draw' ? 0.5 : 0;  
  const expected = expectedScore(current, opponent);  
  return Math.round(current + kFactor * (score - expected));  
}  
  
/** Stockfish seviyesini yaklaşık bir rakip Elo'suna çevirir (levels.ts ile tutarlı). */  
export function approximateEngineElo(level: number): number {  
  const lvl = Math.max(0, Math.min(20, level));  
  if (lvl >= 18) return 2850;  
  return Math.round(1320 + (lvl / 17) * (2600 - 1320));  
}
