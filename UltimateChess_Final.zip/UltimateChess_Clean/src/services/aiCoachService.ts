import type { GameReviewResult } from './gameReviewService';
export class AiCoachNotConfiguredError extends Error {}
export interface CoachInsight { ply: number; message: string; }
export async function requestCoachInsights(_review: GameReviewResult): Promise<CoachInsight[]> {
  throw new AiCoachNotConfiguredError('AI Koç şu anda kullanılamıyor: güvenli bir backend/proxy servisi gerektirir.');
}
