import { create } from 'zustand';
import { StockfishEngine, type EngineStatus, type AnalysisResult } from '../engine/StockfishEngine';
import { uid } from '../utils/id';

interface EngineState {
engine: StockfishEngine;
status: EngineStatus;
errorMessage: string | null;
level: number;
init: () => Promise<void>;
setLevel: (lvl: number) => void;
requestBestMove: (fen: string) => Promise<AnalysisResult>;
reset: () => void;
}

export const useEngineStore = create<EngineState>((set, get) => ({
engine: new StockfishEngine(),
status: 'LOADING',
errorMessage: null,
level: 10,

init: async () => {
const { engine } = get();
engine.onStatusChange((s) => set({ status: s, errorMessage: s === 'ERROR' ? engine.getLastError() : null }));
try {
await engine.init();
engine.setLevel(get().level);
} catch (e) {
set({ status: 'ERROR', errorMessage: (e as Error).message });
}
},

setLevel: (lvl) => {
set({ level: lvl });
get().engine.setLevel(lvl);
},

requestBestMove: async (fen: string) => {
const { engine, level } = get();
if (engine.getStatus() === 'ERROR' || engine.getStatus() === 'LOADING') {
throw new Error('Motor hazır değil. Analiz/oyun başlatılamaz.');
}
const requestId = uid();
const movetimeMs = 250 + (level / 20) * 2250;
return engine.analyze(fen, { movetimeMs }, requestId);
},

reset: () => {
get().engine.destroy();
set({ status: 'LOADING', errorMessage: null, engine: new StockfishEngine() });
},
}));
