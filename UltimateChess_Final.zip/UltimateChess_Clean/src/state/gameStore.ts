import { create } from 'zustand';
import type { Square } from 'chess.js';
import { ChessGame } from '../chess/ChessGame';
import { VARIANT_REGISTRY } from '../variants/registry';
import type { VariantRule, VariantRuntimeState, VariantEvent } from '../variants/types';
import { useEngineStore } from './engineStore';
import { saveGame } from '../storage/gameHistoryStore';

interface GameState {
game: ChessGame;
orientation: 'w' | 'b';
lastMove: { from: string; to: string } | null;
checkSquare: string | null;
variant: VariantRule | null;
variantState: VariantRuntimeState | null;
activeVariantEvents: VariantEvent[];
vsComputer: boolean;
gameOverInfo: { over: boolean; result?: string } | null;
matchInProgress: boolean;

startClassic: (humanColor: 'w' | 'b', vsComputer: boolean) => void;
startVariant: (variantId: string, humanColor: 'w' | 'b') => void;
legalTargetsFor: (square: Square) => Square[];
playMove: (from: Square, to: Square, promotion?: string) => Promise<void>;
performVariantAction: (action: { type: string; payload?: any }) => Promise<void>;
requestComputerMoveIfNeeded: () => Promise<void>;
visibilityMask: boolean[][] | null;
}

export const useGameStore = create<GameState>((set, get) => ({
game: new ChessGame(),
orientation: 'w',
lastMove: null,
checkSquare: null,
variant: null,
variantState: null,
activeVariantEvents: [],
vsComputer: false,
gameOverInfo: null,
matchInProgress: false,
visibilityMask: null,

startClassic: (humanColor, vsComputer) => {
const game = new ChessGame();
set({ game, orientation: humanColor, variant: null, variantState: null, vsComputer, lastMove: null, gameOverInfo: null, matchInProgress: true, visibilityMask: null });
get().requestComputerMoveIfNeeded();
},

startVariant: (variantId, humanColor) => {
const rule = VARIANT_REGISTRY[variantId];
const game = new ChessGame();
const variantState = rule.initialize(game);
const mask = rule.getVisibilityMask ? rule.getVisibilityMask(variantState, humanColor) : null;
set({ game, variant: rule, variantState, orientation: humanColor, vsComputer: true, lastMove: null, gameOverInfo: null, matchInProgress: true, visibilityMask: mask });
},

legalTargetsFor: (square) => {
const { game, variant, variantState } = get();
const moves = game.legalMoves(square);
if (!variant?.onBeforeMove || !variantState) return moves.map((m) => m.to as Square);
return moves
.filter((m) => variant.onBeforeMove!(variantState, game, m.from as Square, m.to as Square).allowed)
.map((m) => m.to as Square);
},

playMove: async (from, to, promotion) => {
const { game, variant, variantState } = get();
if (variant?.onBeforeMove && variantState) {
const guard = variant.onBeforeMove(variantState, game, from, to);
if (!guard.allowed) return; // UI ayrıca guard.reason'ı toast ile gösterebilir
}
const mv = game.move({ from, to, promotion });
if (!mv) return;

let events: VariantEvent[] = [];  
if (variant?.onAfterMove && variantState) {  
  events = variant.onAfterMove(variantState, game);  
}  

const snap = game.snapshot();  
const mask = variant?.getVisibilityMask && variantState ? variant.getVisibilityMask(variantState, get().orientation) : get().visibilityMask;  

set({  
  game,  
  lastMove: { from, to },  
  checkSquare: snap.isCheck ? findKingSquare(game, snap.turn) : null,  
  activeVariantEvents: events,  
  visibilityMask: mask,  
});  

if (snap.isCheckmate || snap.isStalemate || snap.isDraw) {  
  await persistFinishedGame(get());  
  set({ gameOverInfo: { over: true, result: snap.isCheckmate ? `${snap.turn === 'w' ? 'Siyah' : 'Beyaz'} kazandı` : 'Berabere' }, matchInProgress: false });  
  return;  
}  

await get().requestComputerMoveIfNeeded();

},

performVariantAction: async (action) => {
  const { variant, variantState, game } = get();
  if (!variant?.applyCustomAction || !variantState) return;
  const result = variant.applyCustomAction(variantState, game, action, game.raw.turn());
  set({ game, variantState, activeVariantEvents: result.events });
  if (result.success) await get().requestComputerMoveIfNeeded();
},

requestComputerMoveIfNeeded: async () => {
const { game, orientation, vsComputer, variant, variantState } = get();
if (!vsComputer) return;
if (game.raw.turn() === orientation) return; // sıra insanda

const engineStore = useEngineStore.getState();  
try {  
  if (!variant) {  
    const result = await engineStore.requestBestMove(game.fen());  
    if (!result.bestMove) return;  
    const from = result.bestMove.slice(0, 2) as Square;  
    const to = result.bestMove.slice(2, 4) as Square;  
    const promotion = result.bestMove.slice(4) || undefined;  
    await get().playMove(from, to, promotion);  
  } else {  
    // Varyant modunda VariantAIAdapter kullanılır (bkz. variants/ai/VariantAIAdapter.ts)  
    // Kısaltma: burada legal hamleler arasından guard'a uyanlar üzerinden basit seçim örneklenmiştir.  
    const legal = game.legalMoves().filter((m) =>  
      !variant.onBeforeMove || variantState && variant.onBeforeMove(variantState, game, m.from as Square, m.to as Square).allowed  
    );  
    if (!legal.length) return;  
    const pick = legal[Math.floor(Math.random() * legal.length)];  
    await get().playMove(pick.from as Square, pick.to as Square, pick.promotion);  
  }  
} catch (e) {  
  console.error('Bilgisayar hamlesi alınamadı:', e);  
}

},
}));

function findKingSquare(game: ChessGame, color: 'w' | 'b'): string | null {
const board = game.board();
for (const row of board) for (const c of row) if (c && c.type === 'k' && c.color === color) return c.square;
return null;
}

async function persistFinishedGame(state: GameState) {
const snap = state.game.snapshot();
const result: 'win' | 'loss' | 'draw' = snap.isDraw || snap.isStalemate ? 'draw'
: snap.isCheckmate ? (snap.turn !== state.orientation ? 'win' : 'loss') : 'draw';
await saveGame({
date: Date.now(),
mode: state.variant?.id ?? (state.vsComputer ? 'vs-computer' : 'classic'),
opponent: state.vsComputer ? 'Stockfish/AI' : 'Yerel Oyuncu',
userColor: state.orientation,
result,
pgn: snap.pgn,
finalFen: snap.fen,
moveCount: state.game.raw.history().length,
durationSeconds: 0, // gerçek uygulamada zamanlayıcıdan gelir
ratingBefore: 0,
ratingAfter: 0,
});
}
