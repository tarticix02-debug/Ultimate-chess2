import { Chess } from 'chess.js';  
import type { PuzzleDefinition } from './types';  
  
function fenAfterMoves(sanMoves: string[]): string {  
  const c = new Chess();  
  for (const san of sanMoves) {  
    const result = c.move(san);  
    if (!result) throw new Error(`geçersiz hamle "${san}" (dizi: ${sanMoves.join(' ')})`);  
  }  
  return c.fen();  
}  
  
function safeFenAfterMoves(sanMoves: string[], label: string): string | null {  
  try {  
    return fenAfterMoves(sanMoves);  
  } catch (e) {  
    console.error(`[SeedPuzzles] "${label}" oluşturulamadı:`, (e as Error).message);  
    return null;  
  }  
}  
  
// Meşhur "Scholar's Mate" — 1.e4 e5 2.Qh5 Nc6 3.Bc4 Nf6?? 4.Qxf7#  
// (chess.js üzerinden gerçekten oynatılarak FEN türetiliyor, elle FEN yazma riski yok)  
const scholarsMateFen = safeFenAfterMoves(['e4', 'e5', 'Qh5', 'Nc6', 'Bc4', 'Nf6'], "Scholar's Mate");  
  
export const SEED_PUZZLES: PuzzleDefinition[] = [  
  scholarsMateFen && {  
    id: 'seed-scholars-mate',  
    fen: scholarsMateFen,  
    solutionSan: ['Qxf7#'],  
    themes: ['mate'],  
    rating: 700,  
    source: 'seed',  
  },  
  {  
    id: 'seed-back-rank-mate',  
    // Beyaz: Kg1, Ra1, piyonlar f2g2h2 | Siyah: Kg8, piyonlar f7g7h7 (kendi piyonlarının arkasında sıkışmış)  
    fen: '6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1',  
    solutionSan: ['Ra8#'],  
    themes: ['mate', 'endgameTactic'],  
    rating: 900,  
    source: 'seed',  
  },  
  {  
    id: 'seed-knight-fork',  
    // Beyaz At d5, tek hamlede hem Kayıp e8 hem Kale a8'i çatallıyor (Nc7+)  
    fen: 'r3k3/8/8/3N4/8/8/8/4K3 w - - 0 1',  
    solutionSan: ['Nc7+'],  
    themes: ['fork'],  
    rating: 1000,  
    source: 'seed',  
  },  
  {  
    id: 'seed-promotion-basic',  
    fen: '8/P6k/8/8/8/8/7K/8 w - - 0 1',  
    solutionSan: ['a8=Q'],  
    themes: ['promotion'],  
    rating: 800,  
    source: 'seed',  
  },  
  {  
    id: 'seed-discovered-attack',  
    // At e5, Kale e1 → At Kale c6'yı yer VE aynı anda e-hattını açarak şah çeker (çift etkili keşif saldırısı)  
    fen: '4k3/8/2r5/4N3/8/8/8/4R1K1 w - - 0 1',  
    solutionSan: ['Nxc6+'],  
    themes: ['discoveredAttack', 'doubleAttack'],  
    rating: 1300,  
    source: 'seed',  
  },  
  {  
    id: 'seed-skewer',  
    // Fil b4, c3'e giderek Kg6/f6 üzerinden şah çeker; Kral kaçınca Kale h8 şişleniyor  
    fen: '7r/8/5k2/8/1B6/8/8/6K1 w - - 0 1',  
    solutionSan: ['Bc3+', 'Ke6', 'Bxh8'],  
    themes: ['skewer'],  
    rating: 1400,  
    source: 'seed',  
  },  
].filter((p): p is PuzzleDefinition => Boolean(p));
