export function ComingSoonScreen({ title }: { title: string }) {  
  return (  
    <div className="coming-soon">  
      <div className="coming-soon__icon" aria-hidden>◐</div>  
      <h2>{title}</h2>  
      <p>Bu özellik şu anda geliştirilme aşamasında. Henüz gerçek veri/mantık bağlanmadığı için erken gösterilmiyor.</p>  
    </div>  
  );  
}
