import { useNavigate } from 'react-router-dom';  
import { useDashboardData } from '../hooks/useDashboardData';  
import { Card } from '../components/common/Card';  
import { StatChip } from '../components/common/StatChip';  
import { useGameStore } from '../state/gameStore';  
  
const RESULT_LABEL: Record<string, string> = { win: 'Galibiyet', loss: 'Mağlubiyet', draw: 'Berabere' };  
const MODE_LABEL: Record<string, string> = {  
  classic: 'Klasik', 'vs-computer': 'Bilgisayara Karşı',  
  invisible: 'Invisible Chess', chaos: 'Chaos Chess',  
  jackpot: 'Jackpot Chess', treasure: 'Treasure Chess', freeze: 'Freeze Chess',  
};  
  
export function HomeScreen() {  
  const navigate = useNavigate();  
  const { loading, profile, recentGames, stats } = useDashboardData();  
  const startClassic = useGameStore((s) => s.startClassic);  
  
  if (loading) {  
    return <div className="state-panel"><div className="spinner" /><p>Yükleniyor…</p></div>;  
  }  
  
  return (  
    <div className="home-screen">  
      {/* ---- Profil özeti ---- */}  
      <section className="home-header">  
        <div className="home-header__avatar">{profile?.avatarInitial ?? 'O'}</div>  
        <div className="home-header__info">  
          <h1>{profile?.username}</h1>  
          <span className="home-header__rating">Rating: {profile?.rating ?? '—'}</span>  
        </div>  
      </section>  
  
      {/* ---- Hızlı Erişim ---- */}  
      <section className="home-section">  
        <h2 className="home-section__title">Hızlı Erişim</h2>  
        <div className="quick-grid">  
          <Card  
            onClick={() => { startClassic('w', true); navigate('/play'); }}  
            ariaLabel="Hızlı Oyna"  
          >  
            <span className="quick-grid__title">Hızlı Oyna</span>  
            <span className="quick-grid__sub">Bilgisayara karşı, varsayılan seviye</span>  
          </Card>  
          <Card onClick={() => navigate('/play')} ariaLabel="Bilgisayara Karşı">  
            <span className="quick-grid__title">Bilgisayara Karşı</span>  
            <span className="quick-grid__sub">Seviye ve renk seç</span>  
          </Card>  
          <Card onClick={() => navigate('/variants')} ariaLabel="Varyantlar">  
            <span className="quick-grid__title">Varyantlar</span>  
            <span className="quick-grid__sub">5 aktif mod</span>  
          </Card>  
          <Card disabled ariaLabel="Puzzle - yakında">  
            <span className="quick-grid__title">Puzzle</span>  
            <span className="quick-grid__badge">Yakında</span>  
          </Card>  
          <Card disabled ariaLabel="Açılış Antrenmanı - yakında">  
            <span className="quick-grid__title">Açılış Antrenmanı</span>  
            <span className="quick-grid__badge">Yakında</span>  
          </Card>  
          <Card onClick={() => navigate('/stats')} ariaLabel="İstatistikler">  
            <span className="quick-grid__title">İstatistikler</span>  
            <span className="quick-grid__sub">{stats?.totalGames ?? 0} oyun</span>  
          </Card>  
        </div>  
      </section>  
  
      {/* ---- İstatistik Özeti (gerçek veri) ---- */}  
      <section className="home-section">  
        <h2 className="home-section__title">İstatistik Özeti</h2>  
        {stats && stats.totalGames > 0 ? (  
          <div className="stat-chip-row">  
            <StatChip label="Toplam Oyun" value={stats.totalGames} />  
            <StatChip label="Kazanma Oranı" value={`${stats.winRate.toFixed(0)}%`} />  
            <StatChip label="Galibiyet Serisi" value={stats.currentWinStreak} />  
            <StatChip label="Ort. Hamle" value={stats.avgMoveCount.toFixed(0)} />  
          </div>  
        ) : (  
          <EmptyState text="Henüz oynanmış bir oyun yok. İlk oyununuzu başlatın." />  
        )}  
      </section>  
  
      {/* ---- Son Oyunlar (gerçek veri) ---- */}  
      <section className="home-section">  
        <div className="home-section__header">  
          <h2 className="home-section__title">Son Oyunlar</h2>  
          {recentGames.length > 0 && <button className="link-btn" onClick={() => navigate('/stats')}>Tümü</button>}  
        </div>  
        {recentGames.length > 0 ? (  
          <div className="recent-games-list">  
            {recentGames.map((g) => (  
              <Card key={g.id} onClick={() => navigate(`/review/${g.id}`)} className="recent-game-row">  
                <span className={`recent-game-row__result recent-game-row__result--${g.result}`}>{RESULT_LABEL[g.result]}</span>  
                <span className="recent-game-row__mode">{MODE_LABEL[g.mode] ?? g.mode}</span>  
                <span className="recent-game-row__date">{new Date(g.date).toLocaleDateString('tr-TR')}</span>  
              </Card>  
            ))}  
          </div>  
        ) : (  
          <EmptyState text="Oyun geçmişiniz burada görünecek." />  
        )}  
      </section>  
  
      {/* ---- Henüz gerçek veriye sahip olmayan bölümler: dürüstçe "Yakında" ---- */}  
      <section className="home-section home-section--muted">  
        <h2 className="home-section__title">Günlük Görev &amp; Başarımlar</h2>  
        <EmptyState text="Görev ve başarım sistemi henüz aktif değil. Bu bölüm gerçek verilerle bağlandığında burada görünecek." />  
      </section>  
    </div>  
  );  
}  
  
function EmptyState({ text }: { text: string }) {  
  return <div className="empty-state"><p>{text}</p></div>;  
}
