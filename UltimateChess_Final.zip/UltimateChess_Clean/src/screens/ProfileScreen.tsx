import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getProfile, updateProfile, type UserProfile } from '../storage/profileStore';
import { getAllGames } from '../storage/gameHistoryStore';
import { computeStats, type UserStats } from '../services/statsService';
import { getAchievementStatuses } from '../services/achievementService';
import type { AchievementStatus } from '../achievements/types';
import { StatChip } from '../components/common/StatChip';
import { Card } from '../components/common/Card';

export function ProfileScreen() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [stats, setStats] = useState<UserStats | null>(null);
  const [achievements, setAchievements] = useState<AchievementStatus[] | null>(null);
  const [editingName, setEditingName] = useState(false);
  const [nameDraft, setNameDraft] = useState('');
  useEffect(() => { void load(); }, []);
  async function load() { const [p, games, ach] = await Promise.all([getProfile(), getAllGames(), getAchievementStatuses()]); setProfile(p); setStats(computeStats(games)); setAchievements(ach); setNameDraft(p.username); }
  async function saveName() { if (!nameDraft.trim()) return; const n=nameDraft.trim(); const updated=await updateProfile({ username:n, avatarInitial:n[0].toUpperCase() }); setProfile(updated); setEditingName(false); }
  if (!profile || !stats || !achievements) return <div className="state-panel"><div className="spinner" /></div>;
  const unlockedCount=achievements.filter(a=>a.unlocked).length;
  const favoriteMode=Object.entries(stats.byMode).sort((a,b)=>b[1].games-a[1].games)[0];
  return <div className="profile-screen">
    <div className="profile-header"><div className="profile-header__avatar">{profile.avatarInitial}</div><div className="profile-header__info">{editingName ? <div className="profile-name-edit"><input value={nameDraft} onChange={e=>setNameDraft(e.target.value)} maxLength={20}/><button onClick={saveName}>Kaydet</button></div> : <h1 onClick={()=>setEditingName(true)}>{profile.username} ✎</h1>}<span>Rating: {profile.rating} · Puzzle: {profile.puzzleRating}</span></div></div>
    <section className="profile-section"><h2>İstatistikler</h2>{stats.totalGames>0?<div className="stat-chip-row"><StatChip label="Toplam Oyun" value={stats.totalGames}/><StatChip label="Kazanma Oranı" value={`${stats.winRate.toFixed(0)}%`}/><StatChip label="En Uzun Seri" value={stats.longestWinStreak}/><StatChip label="Favori Mod" value={favoriteMode?favoriteMode[0]:'—'}/></div>:<div className="empty-state"><p>Henüz oyun verisi yok.</p></div>}<button className="link-btn" onClick={()=>navigate('/stats')}>Tüm istatistikleri gör</button></section>
    <section className="profile-section"><h2>Başarımlar ({unlockedCount}/{achievements.length})</h2><div className="achievements-grid">{achievements.map(a=><Card key={a.id} className={`achievement-card ${a.unlocked?'achievement-card--unlocked':'achievement-card--locked'}`}><span className="achievement-card__icon">{a.unlocked?'🏆':'🔒'}</span><strong>{a.name}</strong><p>{a.description}</p><div className="achievement-progress"><div className="achievement-progress__bar" style={{width:`${Math.min(100,(a.currentProgress/a.target)*100)}%`}}/></div><span className="achievement-progress__label">{a.currentProgress}/{a.target}</span></Card>)}</div></section>
  </div>;
}
