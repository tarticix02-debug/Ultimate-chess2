import { useEffect, useState } from 'react';  
import { getAllGames } from '../storage/gameHistoryStore';  
import { computeStats, type UserStats } from '../services/statsService';  
import { StatChip } from '../components/common/StatChip';  
  
export function StatsScreen() {  
  const [stats, setStats] = useState<UserStats | null>(null);  
  const [loading, setLoading] = useState(true);  
  
  useEffect(() => {  
    getAllGames().then((games) => { setStats(computeStats(games)); setLoading(false); });  
  }, []);  
  
  if (loading) return <div className="state-panel"><div className="spinner" /></div>;  
  if (!stats || stats.totalGames === 0) return <div className="empty-state"><p>Henüz istatistik oluşturacak veri yok.</p></div>;  
  
  return (  
    <div className="stats-screen">  
      <h1>İstatistikler</h1>  
      <div className="stat-chip-row">  
        <StatChip label="Toplam Oyun" value={stats.totalGames} />  
        <StatChip label="Galibiyet" value={stats.wins} />  
        <StatChip label="Mağlubiyet" value={stats.losses} />  
        <StatChip label="Beraberlik" value={stats.draws} />  
        <StatChip label="Kazanma Oranı" value={`${stats.winRate.toFixed(1)}%`} />  
        <StatChip label="Beyaz K.O." value={`${stats.whiteWinRate.toFixed(1)}%`} />  
        <StatChip label="Siyah K.O." value={`${stats.blackWinRate.toFixed(1)}%`} />  
        <StatChip label="En Uzun Seri" value={stats.longestWinStreak} />  
      </div>  
  
      <h2>Mod Bazında</h2>  
      <div className="mode-stats-list">  
        {Object.entries(stats.byMode).map(([mode, m]) => (  
          <div key={mode} className="mode-stats-row">  
            <span>{mode}</span>  
            <span>{m.games} oyun · {m.winRate.toFixed(0)}% kazanma</span>  
          </div>  
        ))}  
      </div>  
    </div>  
  );  
}
