import { useEffect, useState } from 'react';  
import { useParams } from 'react-router-dom';  
import { Board } from '../components/board/Board';  
import { useGameStore } from '../state/gameStore';  
import { useEngineStore } from '../state/engineStore';  
import { Button } from '../components/common/Button';  
  
export function PlayScreen() {  
  const { variantId } = useParams();  
  const { status, errorMessage, level, setLevel, init } = useEngineStore();  
  const { startClassic, startVariant, matchInProgress, activeVariantEvents, gameOverInfo } = useGameStore();  
  const [color, setColor] = useState<'w' | 'b'>('w');  
  
  useEffect(() => { init(); }, [init]);  
  useEffect(() => () => { useEngineStore.getState().engine.stop(); }, []);
  useEffect(() => { if (variantId && !matchInProgress) startVariant(variantId, 'w'); }, [variantId, matchInProgress, startVariant]);  
  
  if (status === 'LOADING') return <div className="state-panel"><div className="spinner" /><p>Stockfish yükleniyor…</p></div>;  
  if (status === 'ERROR') return (  
    <div className="state-panel state-panel--error">  
      <p>Motor başlatılamadı: {errorMessage}</p>  
      <Button onClick={init}>Tekrar Dene</Button>  
    </div>  
  );  
  
  if (!matchInProgress && !variantId) {  
    return (  
      <div className="setup-panel">  
        <h1>Bilgisayara Karşı</h1>  
        <label>  
          Seviye: {level}  
          <input type="range" min={0} max={20} value={level} onChange={(e) => setLevel(Number(e.target.value))} />  
        </label>  
        <div className="color-pick">  
          <Button variant={color === 'w' ? 'primary' : 'secondary'} onClick={() => setColor('w')}>Beyaz</Button>  
          <Button variant={color === 'b' ? 'primary' : 'secondary'} onClick={() => setColor('b')}>Siyah</Button>  
        </div>  
        <Button onClick={() => startClassic(color, true)}>Oyunu Başlat</Button>  
      </div>  
    );  
  }  
  
  if (!matchInProgress && variantId) {  
    startVariant(variantId, 'w');  
  }  
  
  return (  
    <div className="play-screen">  
      <span className={`engine-badge engine-badge--${status.toLowerCase()}`}>{status}</span>  
      <Board />  
      {activeVariantEvents.map((e) => <div key={e.id} className="event-banner">{e.description}</div>)}  
      {gameOverInfo?.over && (  
        <div className="game-over-modal">  
          <h2>{gameOverInfo.result}</h2>  
          <Button onClick={() => startClassic('w', true)}>Yeni Oyun</Button>  
        </div>  
      )}  
    </div>  
  );  
}
