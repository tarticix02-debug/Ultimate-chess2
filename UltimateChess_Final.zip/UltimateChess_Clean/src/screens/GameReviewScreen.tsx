import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useGameReviewStore } from '../state/gameReviewStore';
import { getAllGames } from '../storage/gameHistoryStore';
import { AnalysisBoard } from '../components/review/AnalysisBoard';
import { EvalGraph } from '../components/review/EvalGraph';
import { EvalBar } from '../components/review/EvalBar';
import { MoveReviewRow } from '../components/review/MoveReviewRow';
import { isReviewableMode } from '../utils/reviewability';

export function GameReviewScreen() {
const { gameId } = useParams();
const { status, progress, result, error, selectedPly, start, selectPly, cancel } = useGameReviewStore();

useEffect(() => {
let active = true;
(async () => {
const games = await getAllGames();
const record = games.find((g) => g.id === gameId);
if (record && active && isReviewableMode(record.mode)) start(record.pgn);
})();
return () => { active = false; cancel(); };
}, [gameId]);

if (status === 'idle' && result === null) return <div className="state-panel"><p>Oyun incelemeye hazır değil.</p></div>;

if (status === 'idle' || status === 'analyzing') {
return (
<div className="state-panel">
<div className="spinner" />
<p>Oyun analiz ediliyor… %{progress}</p>
<button onClick={cancel}>İptal Et</button>
</div>
);
}
if (status === 'error') return <div className="state-panel state-panel--error"><p>Analiz başarısız: {error}</p></div>;
if (status === 'cancelled' || !result) return <div className="state-panel"><p>Analiz iptal edildi.</p></div>;

const currentFen = selectedPly === -1 ? result.moves[0]?.fenBefore ?? '' : result.moves[selectedPly].fenAfter;
const currentMove = selectedPly >= 0 ? result.moves[selectedPly] : null;
const currentCp = result.evalHistoryWhiteCp[selectedPly + 1] ?? 0;

return (
<div className="review-screen">
<div className="review-screen__board-area">
<EvalBar cpWhite={currentCp} mateWhite={currentMove?.evalAfterMate ?? null} />
<AnalysisBoard fen={currentFen} highlightFrom={currentMove?.playedUci.slice(0, 2)} highlightTo={currentMove?.playedUci.slice(2, 4)} />
</div>

<div className="review-screen__summary">  
    <h2>{result.openingName ?? 'Bilinmeyen Açılış'} {result.openingEco && `(${result.openingEco})`}</h2>  
    <div className="accuracy-row">  
      <span>Beyaz Doğruluk: {result.whiteAccuracy.toFixed(1)}%</span>  
      <span>Siyah Doğruluk: {result.blackAccuracy.toFixed(1)}%</span>  
    </div>  
    <EvalGraph evalHistoryWhiteCp={result.evalHistoryWhiteCp} selectedPly={selectedPly} onSelect={selectPly} />  
  </div>  

  {currentMove && (  
    <div className="review-screen__move-detail">  
      <p><strong>{currentMove.san}</strong> — {currentMove.classification.toUpperCase()}</p>  
      <p>  
        Oynanan: {currentMove.playedUci}  
        {currentMove.bestUci && currentMove.bestUci !== currentMove.playedUci && ` | Motor önerisi: ${currentMove.bestUci}`}  
      </p>  
      <p>Doğruluk katkısı: {currentMove.accuracy.toFixed(1)}%</p>  
    </div>  
  )}  

  <div className="review-screen__move-list">  
    {result.moves.map((m, i) => (  
      <MoveReviewRow key={m.ply} move={m} selected={i === selectedPly} onClick={() => selectPly(i)} />  
    ))}  
  </div>  
</div>

);
}
