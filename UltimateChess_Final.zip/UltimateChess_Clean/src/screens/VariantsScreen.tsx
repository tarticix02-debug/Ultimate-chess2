import { useNavigate } from 'react-router-dom';  
import { VARIANT_REGISTRY } from '../variants/registry';  
import { Card } from '../components/common/Card';  
import { useGameStore } from '../state/gameStore';  
  
export function VariantsScreen() {  
  const navigate = useNavigate();  
  const startVariant = useGameStore((s) => s.startVariant);  
  const variants = Object.values(VARIANT_REGISTRY);  
  
  return (  
    <div className="variants-screen">  
      <h1>Varyantlar</h1>  
      <div className="variants-grid">  
        {variants.map((v) => (  
          <Card  
            key={v.id}  
            disabled={v.status === 'planned'}  
            onClick={v.status === 'implemented' ? () => { startVariant(v.id, 'w'); navigate(`/play/variant/${v.id}`); } : undefined}  
            ariaLabel={v.name}  
          >  
            <div className="variant-card__header">  
              <span className="variant-card__name">{v.name}</span>  
              {v.status === 'planned' && <span className="quick-grid__badge">Yakında</span>}  
            </div>  
            <p className="variant-card__desc">{v.description}</p>  
          </Card>  
        ))}  
      </div>  
    </div>  
  );  
}
