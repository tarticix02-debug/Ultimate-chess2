import type { ReactNode } from 'react';
import { useTheme } from '../hooks/useTheme';
import { Card } from '../components/common/Card';

const ACCENTS = ['#4f8cff', '#35c975', '#f5a623', '#ef4444', '#a855f7', '#14b8a6'];

export function SettingsScreen() {
const {
settings, setTheme, setAccent, setSoundEnabled, setHapticEnabled,
setLegalMoveHighlights, setShowLastMoveHighlight, setAutoPromoteToQueen,
} = useTheme();

if (!settings) return <div className="state-panel"><div className="spinner" /></div>;

return (
<div className="settings-screen">
<h1>Ayarlar</h1>

<SettingsSection title="Görünüm">  
    <SettingRow label="Tema">  
      <div className="segmented">  
        {(['dark', 'light', 'system'] as const).map((t) => (  
          <button key={t} className={settings.theme === t ? 'segmented__item segmented__item--active' : 'segmented__item'} onClick={() => setTheme(t)}>  
            {t === 'dark' ? 'Koyu' : t === 'light' ? 'Açık' : 'Sistem'}  
          </button>  
        ))}  
      </div>  
    </SettingRow>  
    <SettingRow label="Vurgu Rengi">  
      <div className="accent-swatches">  
        {ACCENTS.map((c) => (  
          <button key={c} className={`accent-swatch ${settings.accentColor === c ? 'accent-swatch--active' : ''}`} style={{ background: c }} onClick={() => setAccent(c)} aria-label={`Vurgu rengi ${c}`} />  
        ))}  
      </div>  
    </SettingRow>  
  </SettingsSection>  

  <SettingsSection title="Oyun">  
    <ToggleRow label="Geçerli hamle göstergeleri" value={settings.legalMoveHighlights} onChange={setLegalMoveHighlights} />  
    <ToggleRow label="Son hamle vurgusu" value={settings.showLastMoveHighlight} onChange={setShowLastMoveHighlight} />  
    <ToggleRow label="Otomatik vezir terfisi" value={settings.autoPromoteToQueen} onChange={setAutoPromoteToQueen} />  
  </SettingsSection>  

  <SettingsSection title="Ses ve Titreşim">  
    <ToggleRow label="Ses efektleri" value={settings.soundEnabled} onChange={setSoundEnabled} />  
    <ToggleRow label="Titreşim (Haptic)" value={settings.hapticEnabled} onChange={setHapticEnabled} />  
  </SettingsSection>  

  <SettingsSection title="Dil">  
    <div className="empty-state"><p>Çoklu dil desteği (TR/EN) henüz aktif değil. Şu an yalnızca Türkçe arayüz mevcuttur.</p></div>  
  </SettingsSection>  

  <SettingsSection title="Hesap">  
    <div className="empty-state"><p>Çevrimiçi hesap sistemi bu sürümde yoktur; tüm veriler yalnızca bu cihazda saklanır.</p></div>  
  </SettingsSection>  
</div>

);
}

function SettingsSection({ title, children }: { title: string; children: ReactNode }) {
return <section className="settings-section"><h2>{title}</h2><Card className="settings-card">{children}</Card></section>;
}
function SettingRow({ label, children }: { label: string; children: ReactNode }) {
return <div className="setting-row"><span>{label}</span>{children}</div>;
}
function ToggleRow({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
return (
<div className="setting-row">
<span>{label}</span>
<button role="switch" aria-checked={value} className={`switch ${value ? 'switch--on' : ''}`} onClick={() => onChange(!value)}>
<span className="switch__thumb" />
</button>
</div>
);
}

