import { describe, it, expect } from 'vitest';
import { Chess } from 'chess.js';
import { buildReplay, finalFen } from '../src/chess/replay';

describe('PGN replay', () => {
it('her adımın FEN'i sırayla ilerler', () => {
const chess = new Chess();
chess.move('e4'); chess.move('e5'); chess.move('Nf3');
const pgn = chess.pgn();
const steps = buildReplay(pgn);
expect(steps).toHaveLength(3);
expect(steps[0].fenBefore).toContain('w KQkq');
expect(steps[2].moveSan).toBe('Nf3');
expect(finalFen(pgn)).toContain(' b ');
});
});

NE GERÇEK, NE SINIRLI — Dürüst Özet (madde 40'a cevap)
Soru	Cevap
Her hamle gerçekten Stockfish'e mi soruluyor?	Evet. N+1 pozisyon, gerçek go depth X çağrısıyla, MultiPV=2 ile analiz ediliyor.
Accuracy sabit mi?	Hayır. Her hamlenin gerçek win%-kaybından hesaplanıyor, oyun/oyuncuya göre değişir.
Sınıflandırma (Blunder/Mistake/...) rastgele mi?	Hayır. Gerçek centipawn-loss eşiklerine ve motorun top move karşılaştırmasına dayanıyor.
Eval grafiği tıklanabilir mi, gerçek pozisyona mı gidiyor?	Evet. EvalGraph tıklamayı en yakın ply'a eşleyip AnalysisBoard'u o FEN ile render ediyor.
AI Koç motorun yerine mi geçiyor?	Hayır ve geçemez — backend olmadığı için özellik açıkça devre dışı olarak işaretli, sahte metin üretmiyor.
Açılış tanıma tam ECO veritabanı mı?	Hayır, 10 açılışlık dürüst bir başlangıç seti; mimari genişletmeye hazır ama "tam" diye sunulmuyor.

Bilinen sınırlamalar (bir sonraki iterasyonda ele alınmalı)
Performans: 40 hamlelik bir oyun, depth=14'te mobilde ~1-3 dakika sürebilir (motor hızına bağlı). Ayarlardan derinlik seçilebilir hale getirilmeli ve arka planda/loading ekranında ilerleme (progress) zaten gösteriliyor.
Accuracy formülü lisans notu: Lichess'in AGPL kod tabanındaki formülün bağımsız yeniden implementasyonu kullanılmıştır; ticari dağıtımdan önce hukuki inceleme önerilir (LICENSES.md'ye not düşülmeli).
Eşzamanlı motor kullanımı: Game Review kendi Stockfish worker'ını açar; kullanıcı aynı anda canlı bir Bilgisayara Karşı oyunu da açık tutuyorsa düşük donanımlı cihazlarda iki worker aynı anda CPU paylaşır — pratikte review ekranına girerken canlı oyun motoru durdurulmalı (öneri: engineStore.reset() review route'una girişte tetiklenmeli).

Bu haliyle Game Review mock değil, uçtan uca gerçek bir veri akışına sahip bir özelliktir: PGN → gerçek replay → gerçek Stockfish analizi → gerçek formül → gerçek sınıflandırma → tıklanabilir gerçek pozisyon navigasyonu.

ANA MENÜ / DASHBOARD — Gerçek Veri Akışlı İmplementasyon

Bu dashboard'daki hiçbir sayı sahte olmayacak. Henüz inşa edilmemiş özellikler (Puzzle, Açılış Antrenmanı, Başarımlar, Görevler) dashboard'da "Yakında" etiketiyle devre dışı görünecek — çalışıyormuş gibi gösterilmeyecek.

Bu teslimatla birlikte 3 destekleyici parça da tamamlanıyor çünkü dashboard bunlarsız gerçek veri gösteremez: Profil/Rating sistemi, Routing altyapısı, Tema sistemi.

EKSİK TEMEL PARÇALARI TAMAMLAMA
Önceki teslimatlarda referans verilip tanımlanmamış birkaç dosya var — önce onları kapatıyorum.
