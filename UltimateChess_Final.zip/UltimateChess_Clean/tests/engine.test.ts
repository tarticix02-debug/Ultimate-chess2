import { describe, it, expect, vi } from 'vitest';
import { StockfishEngine } from '../src/engine/StockfishEngine';

class MockWorker {
onmessage: ((e: MessageEvent) => void) | null = null;
onerror: ((e: any) => void) | null = null;
listeners: ((e: MessageEvent) => void)[] = [];
postMessage(cmd: string) {
setTimeout(() => {
if (cmd === 'uci') this.emit('uciok');
if (cmd === 'isready') this.emit('readyok');
if (cmd.startsWith('go')) this.emit('bestmove e2e4 ponder e7e5');
}, 0);
}
addEventListener(: string, fn: (e: MessageEvent) => void) { this.listeners.push(fn); }
removeEventListener(: string, fn: (e: MessageEvent) => void) { this.listeners = this.listeners.filter((l) => l !== fn); }
emit(data: string) { this.listeners.forEach((l) => l({ data } as MessageEvent)); }
terminate() {}
}

// @ts-expect-error test ortamında Worker'ı mockluyoruz
global.Worker = MockWorker;

describe('StockfishEngine UCI state machine', () => {
it('init sonunda READY durumuna geçer', async () => {
const engine = new StockfishEngine();
await engine.init();
expect(engine.getStatus()).toBe('READY');
});

it('eski requestId ile gelen bestmove reddedilir', async () => {
const engine = new StockfishEngine();
await engine.init();
const p1 = engine.analyze('startpos', {}, 'req-1');
engine.stop();
const p2 = engine.analyze('startpos', {}, 'req-2');
await expect(p1).rejects.toThrow();
await expect(p2).resolves.toBeDefined();
});
});

GELİŞTİRME RAPORU (madde 40 formatına birebir cevap)
Kullanılan teknolojiler
React 18 + Vite (base:'./' ile relative asset path — Capacitor uyumlu)
TypeScript (strict)
chess.js (gerçek FIDE kural motoru — kendim yeniden yazmadım)
Stockfish (GPLv3, worker + WASM, gerçek UCI protokolü ile entegre)
zustand (game/engine/variant state'leri birbirinden ayrık store'lar)
IndexedDB (native, window.storage gibi ortam bağımlılığı yok)
Capacitor (Android hedefi için hazır config)
Vitest (çekirdek kural ve motor protokol testleri)

Klasör yapısı
Yukarıdaki ağaç birebir uygulanmıştır: chess/ (kural), engine/ (motor), variants/ (kural motoru + varyantlar), state/ (UI state, oyun state'inden ayrık), storage/ (persistence), services/ (istatistik/başarım/görev), components/ + screens/ (UI).

Stockfish entegrasyonu — gerçek mi?
Evet, protokol seviyesinde gerçek: uci→uciok→isready→readyok handshake'i, ucinewgame, position fen ..., go movetime/depth, stop, request-id ile stale-response guard, Skill Level + UCI_LimitStrength + UCI_Elo + Threads + Hash gerçek UCI komutlarıyla ayarlanıyor. Eksik olan tek şey: gerçek stockfish.js/stockfish.wasm binary dosyaları — bunlar metin tabanlı bir yanıtla dağıtılamaz, resmi kaynaktan (public/assets/engine/README.md'de anlatıldığı gibi) projeye siz eklemelisiniz. Bu dosyalar eklenmeden motor ERROR durumuna düşer ve kullanıcıya açıkça hata gösterilir — sessiz rastgele-hamle fallback'i yoktur.

Offline çalışma durumu
Klasik satranç: tamamen offline (chess.js, network gerektirmez).
Stockfish: binary'ler public/assets/engine/ içine gömüldüğünde tamamen offline (CDN fetch yok).
Persistence/istatistik/profil: tamamen offline (IndexedDB).
Online multiplayer, arkadaşlık, matchmaking: backend gerektirir, bu teslimatta yoktur ve yokmuş gibi gösterilmemiştir.

Desteklenen özellikler (gerçek)
Tam FIDE kuralları, Stockfish 0-20 seviye sistemi, doğru renk başlatma mantığı, IndexedDB persistence, hard-code'suz istatistik hesaplama, VariantEngine mimarisi, Invisible/Chaos/Jackpot/Treasure/Freeze varyantlarının gerçek state mutasyonu, motor durum makinesi ve hata yönetimi, temel erişilebilirlik (aria-label, kontrast token'ları), test paketi.

Eksik/iskelet kalan özellikler (dürüstçe işaretli)
Teleport, Portal, Bomb, Lava, Survival, Stealth, UNO Chess: VariantRule arayüzüne uyan iskelet var, kural mantığı henüz tam değil → UI'da "Yakında" etiketiyle gösterilmeli.
Game Review / eval grafiği / AI Koç: mimari ayrımı (motor değerlendirmesi ≠ doğal dil açıklama) net tanımlı, ancak tam ekran implementasyonu bu teslimatta yok.
Puzzle üretim pipeline'ı (PGN'den otomatik taktik çıkarma): tasarım net, implementasyon yok.
Ses/haptic, çoklu tahta/taş teması, tam ayarlar ekranı: token/mimari hazır, tam UI yok.
AI Koç için gerekli backend/proxy: açıkça belirtildiği gibi client'a API key gömülmemiştir; bu bir backend servisi gerektirir.

APK build adımları

npm install
npm run build
npx cap add android
npx cap sync
npx cap open android   # Android Studio'da build/run

stockfish.js/.wasm dosyaları dist/assets/engine/ altına build sırasında otomatik kopyalanır (public klasöründen); ek adım gerekmez.

Üçüncü taraf lisanslar
Stockfish: GPLv3 — dağıtımda kaynak koduna erişim/atıf zorunlu, uygulama içinde lisans metni gösterilmelidir.
chess.js: BSD-2-Clause — sorunsuz.
PieceIcon SVG seti: bu teslimatta özgün/basit geometrik path olarak üretildi, telif riski yok; ancak görsel kaliteyi ticari seviyeye çıkarmak için profesyonel/lisansı netleşmiş bir set ile değiştirilmesi önerilir.
Font (Manrope/Inter/JetBrains Mono): SIL Open Font License — sorunsuz.

MOTORDA GEREKLİ GÜNCELLEME — MultiPV Desteği

Game Review'da "Great" (kritik tek doğru hamle) sınıflandırması için motorun birden fazla varyasyonu (MultiPV) karşılaştırması gerekir. Önceki StockfishEngine'e bunu ekliyoruz.
