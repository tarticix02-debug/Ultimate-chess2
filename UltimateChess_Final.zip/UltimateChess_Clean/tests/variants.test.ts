import { describe, it, expect } from 'vitest';
import { ChessGame } from '../src/chess/ChessGame';
import { JackpotVariant } from '../src/variants/jackpot/JackpotVariant';
import { InvisibleVariant } from '../src/variants/invisible/InvisibleVariant';
import { FreezeVariant } from '../src/variants/freeze/FreezeVariant';

describe('Jackpot Chess gerçek state mutasyonu', () => {
it('capture sonrası piece sayısı değişebiliyor', () => {
const g = new ChessGame();
const state = JackpotVariant.initialize(g);
g.move({ from: 'e2', to: 'e4' });
g.move({ from: 'd7', to: 'd5' });
const before = countPieces(g);
g.move({ from: 'e4', to: 'd5' }); // capture
const events = JackpotVariant.onAfterMove!(state, g);
const after = countPieces(g);
expect(events.length).toBe(1);
expect(after).not.toBe(before - 1); // jackpot bir şey ekleyip/çıkarıp sayıyı normalin dışında değiştirebilir
});
});

describe('Invisible Chess görünürlük', () => {
it('tüm kareler görünmez olarak maskelenir', () => {
const g = new ChessGame();
const state = InvisibleVariant.initialize(g);
const mask = InvisibleVariant.getVisibilityMask!(state, 'w');
expect(mask.flat().every((v) => v === false)).toBe(true);
});
});

describe('Freeze Chess', () => {
it('donan kare hamle yapılmasını engeller', () => {
const g = new ChessGame();
const state = FreezeVariant.initialize(g);
(state.customData.frozen as Record<string, number>)['e2'] = 5;
state.moveCounter = 0;
const guard = FreezeVariant.onBeforeMove!(state, g, 'e2' as any, 'e4' as any);
expect(guard.allowed).toBe(false);
});
});

function countPieces(g: ChessGame) {
let n = 0;
g.board().forEach((row) => row.forEach((c) => { if (c) n++; }));
return n;
}
