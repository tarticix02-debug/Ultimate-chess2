import { describe, it, expect } from 'vitest';
import { playSound } from '../src/services/soundService';
import { triggerHaptic } from '../src/services/hapticService';

describe('Ses/Haptic servisleri hata fırlatmaz', () => {
it('AudioContext/indexedDB olmayan ortamda playSound sessizce döner', async () => {
await expect(playSound('move')).resolves.toBeUndefined();
});

it('vibrate API olmayan ortamda triggerHaptic sessizce döner', async () => {
await expect(triggerHaptic('light')).resolves.toBeUndefined();
});
});

DÜRÜST ÖZET
Bileşen	Durum
Piyon terfisi (madde 4 eksiği)	✅ Artık gerçek — PromotionPicker modalı, autoPromoteToQueen ayarı ile atlanabilir
Ses sistemi	✅ Gerçek ama sentetik (Web Audio) — mp3 asset yok, offline çalışır, toggle gerçekten işlevsel
Haptic	✅ Gerçek navigator.vibrate(), toggle gerçekten işlevsel
Başarım sistemi	✅ Gerçek — 18 başarım, tamamı gerçek istatistik/puzzle/açılış verisinden hesaplanıyor, kalıcı "ilk açılış" zaman damgası, toast bildirimi
Profil ekranı	✅ Gerçek veri — rating, puzzle rating, favori mod, başarım ilerlemesi, kullanıcı adı düzenlenebilir ve kalıcı
Ayarlar ekranı	✅ Tema/accent/legal-move/last-move/auto-promote/ses/haptic — hepsi gerçekten bir şeyi değiştiriyor. Dil ve Hesap bölümleri dürüstçe "henüz aktif değil"

GÜNLÜK GÖREVLER — Gerçek Veriden Üretilen, Kalıcı Seçimli Görev Sistemi
Bu modülü seçtim çünkü artık gerekli tüm alt yapı hazır: gerçek oyun kayıtları, puzzle attempt'leri, açılış antrenman oturumları. Görevler bunları filtreleyerek hesaplanacak — hiçbir sayaç bağımsız/sahte olmayacak.

Önce dürüst bir düzeltme yapmam gerekiyor: Bu implementasyonu yazarken fark ettim ki önceki teslimatlardaki bazı testler (gameStorePromotion.test.ts gibi) ve store'lar (getSettings, getProfile vb.) IndexedDB'ye bağımlı, ama Vitest'in varsayılan test ortamında gerçek tarayıcı IndexedDB'si yok. Bu, önceki turlarda gözden kaçırdığım gerçek bir boşluktu. Şimdi hem bunu düzeltiyorum (fake-indexeddb polyfill ile) hem de kritik oyun akışını, ikincil sistemlerin (başarım/görev) hata vermesi durumunda çökmeyecek şekilde savunmaya alıyorum.
