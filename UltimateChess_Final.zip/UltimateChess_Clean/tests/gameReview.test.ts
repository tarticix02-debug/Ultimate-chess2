import { describe, it, expect } from 'vitest';
import { winPercentWhite, accuracyFromLoss, classifyMove } from '../src/engine/evaluation';
import { identifyOpening } from '../src/services/openingService';

describe('değerlendirme formülleri', () => {
it('eşit pozisyonda win% ~50 olmalı', () => {
expect(winPercentWhite({ cpWhite: 0, mateWhite: null })).toBeCloseTo(50, 0);
});

it('büyük cp avantajı yüksek win% üretir', () => {
expect(winPercentWhite({ cpWhite: 800, mateWhite: null })).toBeGreaterThan(90);
});

it('mat pozisyonu 0 veya 100 döner', () => {
expect(winPercentWhite({ cpWhite: null, mateWhite: 3 })).toBe(100);
expect(winPercentWhite({ cpWhite: null, mateWhite: -2 })).toBe(0);
});

it('kayıp yoksa accuracy ~100 olmalı', () => {
expect(accuracyFromLoss(0)).toBeGreaterThan(99);
});

it('büyük win% kaybında accuracy düşük olmalı', () => {
expect(accuracyFromLoss(40)).toBeLessThan(30);
});

it('top move + büyük kritiklik farkı -> great', () => {
const cls = classifyMove({ winPercentLoss: 0, playedIsTopEngineMove: true, topMoveCriticalityGap: 15, isBookMove: false });
expect(cls).toBe('great');
});

it('top move + düşük kritiklik farkı -> best', () => {
const cls = classifyMove({ winPercentLoss: 0, playedIsTopEngineMove: true, topMoveCriticalityGap: 2, isBookMove: false });
expect(cls).toBe('best');
});

it('büyük winPercentLoss -> blunder', () => {
const cls = classifyMove({ winPercentLoss: 35, playedIsTopEngineMove: false, topMoveCriticalityGap: 0, isBookMove: false });
expect(cls).toBe('blunder');
});
});

describe('açılış tanıma', () => {
it('İtalyan açılışını tanır', () => {
expect(identifyOpening(['e4', 'e5', 'Nf3', 'Nc6', 'Bc4']).name).toBe('İtalyan Açılışı');
});

it('bilinmeyen dizide null döner', () => {
expect(identifyOpening(['a3', 'a6', 'a4']).name).toBeNull();
});
});
